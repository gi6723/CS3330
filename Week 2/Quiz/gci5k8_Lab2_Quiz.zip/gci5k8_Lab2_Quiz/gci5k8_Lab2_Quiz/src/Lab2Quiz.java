public class Lab2Quiz {
    /*
     * This program declares and initializes variables for a course number, student name, and section number,
     * then prints a message to the console using those variables.
     */
    public static void main(String[] args) {
        //Declare and initialize variables
        String courseNumber = "3330";
        String studentName = "Gianni Ioannou";
        int section = 1;

        //Print message to console
        System.out.println("My name is " + studentName + ", I am taking the " + courseNumber + " course section " + section +".");
    }
}
