
public class DesiredIncome {
    /**
     *This program takes in a persons, name, age and desired annual income
     *in variables and prints a message to the console.
     */
    public static void main(String[] args) {
        //declaring variables
        String name = "Gianni Ioannou";
        int age = 20;
        double annualPay = 1000000.00;

        //Display Message in console
        System.out.println("My name is " + name + ", my age is " + age + " and");
        System.out.println("I hope to earn $" + annualPay + " per year.");
    }
}
