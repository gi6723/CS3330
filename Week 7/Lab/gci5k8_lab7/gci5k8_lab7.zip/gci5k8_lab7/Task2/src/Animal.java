//Represents a generic animal
public class Animal {
    public String say() {
        return "";
    }
}
