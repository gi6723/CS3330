//Represents a dog which represents an animal
public class Dog extends Animal {
    //Overrides the say method to return the dogs sound
    @Override
    public String say() {
        return "arf-arf";
    }
}
