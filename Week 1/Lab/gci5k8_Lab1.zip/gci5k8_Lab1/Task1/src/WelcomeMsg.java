public class WelcomeMsg {
    public static void main(String[] args) {
        // This is a simple Java program that prints a welcome message to the console.
        System.out.println("Welcome to 3330 course!");
    }
}
