public class AsciiJavaLogo {
    public static void main(String[] args) {
        /*
        The objective of this program is to print a specific pattern using asterisks (*).
        The pattern spells the word Java using asterisks.
         */
        System.out.println("    *     *     *     *     *");
        System.out.println("    *    * *     *   *     * *");
        System.out.println("*   *   *****     * *     *****");
        System.out.println(" **    *     *     *     *     *");
    }
}
